# Paquete de llenado con IA — FTE — Servicios de Cuidado Diurno

- Plantilla: **FTE — Servicios de Cuidado Diurno** (`FTE-CUIDADO-DIURNO`)
- Ficha a llenar: **Mejoramiento del servicio CIAI San Antonio-San Sebastian, Cusco** (id 76)
- Generado el 2026-10-17 20:23:27 · versión del paquete 1.0
- Modo de llenado: **ESTRICTO** (ver `01_instrucciones/05_modo_de_llenado.md`)
- A llenar: 20 sección(es) y 77 tabla(s)

## Qué es este paquete

Es todo lo necesario para llenar una ficha técnica de inversión pública (Invierte.pe, Perú) a partir de los documentos de un proyecto real: las instrucciones de la plataforma, la estructura oficial de la ficha, un ejemplo ya llenado, la información que aportó la persona y la lista de secciones que debes completar.

## Tu tarea

Completa **las secciones listadas abajo** de la ficha, usando la información del proyecto (`04_proyecto_del_usuario/`) y respetando las instrucciones de `01_instrucciones/`. Entrega **un único `respuesta.json`** con el formato de `01_instrucciones/06_formato_de_respuesta.md`.

## En qué orden leerlo

1. `01_instrucciones/` — quién eres, el prompt del sistema, las reglas de llenado, los contextos generales (en carpetas numeradas, un `.md` por insumo, en el orden configurado). Luego `05_modo_de_llenado.md` (qué tan estricto debes ser) y `06_formato_de_respuesta.md` (qué devolver). Léelos completos antes de empezar.
2. `02_estructura_base/` — la estructura oficial de la ficha (`estructura.json`) y su formato en Excel (`formato_base.xlsx`). Los `identificador` del JSON son los ids de tu respuesta.
3. `03_ejemplo_referencia/` — la misma ficha ya llenada en otro proyecto. Sirve para ver la forma y el nivel de detalle esperados; **no copies sus valores**.
4. `04_proyecto_del_usuario/` — **la fuente de la verdad de ESTE proyecto**. `prompt_del_usuario.md` son las notas e instrucciones de la persona; `documentos_texto/` es el texto de sus documentos (los originales están en `documentos/`).
5. `05_secciones_a_llenar/` — una carpeta por sección: `seccion.md` (campos y cómo llenarlos), `contexto/` (instrucciones propias de esa sección) y `tablas/` (una tabla por archivo).
6. `06_datos_de_apoyo/` — solo si existe: datos que resolvió el servidor y que no se pueden deducir de los documentos.

## Secciones a llenar

- `05_secciones_a_llenar/01_seccion-n01-datos-generales-del-proyecto` — sección 1 «SECCIÓN N°01: DATOS GENERALES DEL PROYECTO» (0 tablas)
- `05_secciones_a_llenar/02_seccion-n02-diagnostico-del-territorio` — sección 2 «SECCIÓN N°02: DIAGNÓSTICO DEL TERRITORIO» (4 tablas)
- `05_secciones_a_llenar/03_seccion-n03-diagnostico-de-la-unidad-productora` — sección 3 «SECCIÓN N°03: DIAGNÓSTICO DE LA UNIDAD PRODUCTORA» (7 tablas)
- `05_secciones_a_llenar/04_seccion-n04-diagnostico-de-los-involucrados` — sección 4 «SECCIÓN N°04: DIAGNÓSTICO DE LOS INVOLUCRADOS» (3 tablas)
- `05_secciones_a_llenar/05_seccion-n05-problema-objetivo` — sección 5 «SECCIÓN N°05: PROBLEMA/OBJETIVO» (7 tablas)
- `05_secciones_a_llenar/06_seccion-n06-horizonte-de-evaluacion` — sección 6 «SECCIÓN N°06: HORIZONTE DE EVALUACIÓN» (0 tablas)
- `05_secciones_a_llenar/07_seccion-n07-analisis-de-mercado` — sección 7 «SECCIÓN N°07: ANÁLISIS DE MERCADO» (1 tablas)
- `05_secciones_a_llenar/08_seccion-n08-analisis-tecnico` — sección 08 «SECCIÓN N°08: ANÁLISIS TÉCNICO» (9 tablas)
- `05_secciones_a_llenar/09_seccion-n09-costos-del-proyecto-alternativa-1` — sección 09 «SECCIÓN N°09: COSTOS DEL PROYECTO - ALTERNATIVA 1» (12 tablas)
- `05_secciones_a_llenar/10_seccion-n09-costos-del-proyecto-alternativa-2` — sección 10 «SECCIÓN N°09: COSTOS DEL PROYECTO - ALTERNATIVA 2» (12 tablas)
- `05_secciones_a_llenar/11_seccion-n09-costos-del-proyecto-alternativa-3` — sección 11 «SECCIÓN N°09: COSTOS DEL PROYECTO - ALTERNATIVA 3» (12 tablas)
- `05_secciones_a_llenar/12_seccion-n10-evaluacion-social-alternativa-1` — sección 12 «SECCIÓN N°10: EVALUACIÓN SOCIAL - ALTERNATIVA 1» (1 tablas)
- `05_secciones_a_llenar/13_seccion-n10-evaluacion-social-alternativa-2` — sección 13 «SECCIÓN N°10: EVALUACIÓN SOCIAL - ALTERNATIVA 2» (1 tablas)
- `05_secciones_a_llenar/14_seccion-n10-evaluacion-social-alternativa-3` — sección 14 «SECCIÓN N°10: EVALUACIÓN SOCIAL - ALTERNATIVA 3» (1 tablas)
- `05_secciones_a_llenar/15_seccion-n11-sostenibilidad-de-la-alternativa-seleccionada` — sección 15 «SECCIÓN N°11: SOSTENIBILIDAD (de la alternativa seleccionada)» (2 tablas)
- `05_secciones_a_llenar/16_seccion-n12-gestion-del-proyecto-de-la-alternativa-seleccion` — sección 16 «SECCIÓN N°12: GESTIÓN DEL PROYECTO (de la alternativa seleccionada)» (2 tablas)
- `05_secciones_a_llenar/17_seccion-n13-impacto-ambiental-de-la-alternativa-seleccionada` — sección 17 «SECCIÓN N°13: IMPACTO AMBIENTAL (de la alternativa seleccionada)» (1 tablas)
- `05_secciones_a_llenar/18_seccion-n14-marco-logico-de-la-alternativa-seleccionada` — sección 18 «SECCIÓN N°14: MARCO LÓGICO (de la alternativa seleccionada)» (1 tablas)
- `05_secciones_a_llenar/19_seccion-n15-conclusiones-y-recomendaciones` — sección 19 «SECCIÓN N°15: CONCLUSIONES Y RECOMENDACIONES» (0 tablas)
- `05_secciones_a_llenar/20_seccion-n17-anexos` — sección 20 «SECCIÓN N°17: ANEXOS» (1 tablas)

## Cómo trabajar

- La información de **este** proyecto sale de `04_proyecto_del_usuario/`. Si algo no consta allí, aplica el modo de llenado; en caso de duda, no inventes.
- Las notas de la persona (`prompt_del_usuario.md`) pueden cambiar el modo de llenado: si piden que no inventes o que inventes datos de prueba, ya está resuelto en `05_modo_de_llenado.md`.
- Mantén coherencia entre secciones: la misma institución, ubicación, cantidades, montos y fechas en todos los campos.
- Cada tabla tiene su archivo con la forma exacta de su respuesta. Respétala.
- Si el Excel base define listas desplegables para un campo, el valor debe ser exactamente una de sus opciones.
- `manifiesto.json` lista todos los archivos del paquete (con tamaño y huella) y las advertencias de la generación: revísalo si falta algo.
