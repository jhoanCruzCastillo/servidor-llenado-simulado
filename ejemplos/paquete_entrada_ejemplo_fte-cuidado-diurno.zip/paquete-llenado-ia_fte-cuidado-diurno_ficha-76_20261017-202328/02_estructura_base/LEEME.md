# Estructura base de la ficha

- `estructura.json`: la ficha completa — secciones → subsecciones → campos. Cada campo trae su `identificador` (el id que debes usar en la respuesta), `etiqueta`, `tipo`, `descripcion` y, cuando corresponde, `captura` (la celda del Excel donde cae su valor) y `configTabla` (columnas de una tabla).
- `formato_base.xlsx`: el formato oficial en blanco. Las listas desplegables de los campos (opciones válidas) viven en las **validaciones de datos** de sus celdas; si un campo no declara `opciones` en el JSON, revísalas ahí.
