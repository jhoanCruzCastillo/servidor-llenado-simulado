La persona no cargó documentos; la información del proyecto está solo en `prompt_del_usuario.md`.
