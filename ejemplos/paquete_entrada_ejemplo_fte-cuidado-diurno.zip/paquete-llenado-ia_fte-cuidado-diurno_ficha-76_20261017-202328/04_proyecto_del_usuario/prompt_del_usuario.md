# Notas adicionales del cliente

Texto que escribió la persona en la «fuente de la verdad». **Son sus instrucciones para este llenado** y deciden el modo de llenado.

Prueba del paquete: el proyecto es de mejoramiento. Usa solo datos reales; si algo no consta, déjalo vacío.
