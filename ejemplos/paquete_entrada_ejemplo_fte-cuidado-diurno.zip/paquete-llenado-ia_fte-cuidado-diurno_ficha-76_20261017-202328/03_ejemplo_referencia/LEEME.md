# Ejemplo de referencia: «Mejoramiento del servicio CIAI San Antonio-San Sebastian, Cusco»

Esta misma ficha ya llenada en OTRO proyecto. Sirve para ver **qué celdas se llenan, con qué forma y con qué nivel de detalle**. **No copies sus valores**: los datos de ESTE proyecto salen de `04_proyecto_del_usuario/` (salvo lo que el modo de llenado permita inferir).

- `ejemplo.json`: `valores` (identificador → valor; las tablas van como JSON en texto) y `fuentes` (de dónde salió cada dato).
- `ejemplo.xlsx`: el Excel de ese ejemplo, si existe una copia guardada.
