# Invierte.pe

## Marco normativo
Sistema Nacional de Programación Multianual y Gestión de Inversiones (Invierte.pe), Directiva N.° 001-2019-EF/63.01. Fases del Ciclo de Inversión: Programación Multianual, Formulación y Evaluación, Ejecución, Funcionamiento.

## Naturalezas de intervención de un Proyecto de Inversión (PI) — son EXACTAMENTE estas 4, ninguna otra
- **Creación**: dotar del bien o servicio en áreas donde NO existe una Unidad Productora (UP) — incrementa cobertura partiendo de cero.
- **Mejoramiento**: intervenciones sobre una UP existente orientadas a cumplir el nivel de servicio y/o los estándares de calidad de los factores de producción establecidos por el Sector — presta servicios de mayor calidad a usuarios que ya disponen de él.
- **Ampliación**: incrementa la capacidad de una UP existente para proveer el bien/servicio a NUEVOS usuarios — incrementa cobertura.
- **Recuperación**: recupera la capacidad de prestación del bien/servicio en una UP existente cuyos factores de producción colapsaron o fueron dañados/destruidos.
Cada ficha técnica estándar admite solo un subconjunto de estas 4 (revisa el "Contexto general" propio de la ficha) — nunca asumas que las 4 aplican solo porque son las oficiales del marco normativo.

## Denominación de un proyecto de inversión
Siempre 3 elementos: **Naturaleza** (qué se va a hacer) + **Objeto de la intervención** (el bien/servicio y el nombre de la UP) + **Localización** (dónde se ubica la UP — centro poblado/distrito/provincia/departamento). Ejemplo oficial: "Mejoramiento [naturaleza] del servicio de transitabilidad vial de la carretera vecinal PA 627 [objeto] del distrito de Chontabamba, de la provincia de Oxapampa, del departamento de Pasco [localización]".

## Glosario (Anexo 8 de la Guía General MEF/DGPMI)
- **Unidad Productora (UP)**: conjunto de recursos o factores productivos (infraestructura, equipos, personal, organización, capacidades de gestión) que, articulados entre sí, tienen la capacidad de proveer bienes o servicios a la población objetivo.
- **Brecha**: diferencia entre la oferta disponible optimizada (incluye infraestructura natural) y la demanda, a una fecha y ámbito geográfico determinado — se expresa en cantidad (cobertura) y/o calidad (condiciones del acceso al servicio).
- **Factor de producción**: recurso tangible o intangible que usa una UP para producir el servicio (infraestructura física, equipo, mobiliario, terrenos, capacidades de gestión, personal, materiales, insumos).
- **Horizonte de evaluación**: periodo para evaluar beneficios y costos de un PI — ejecución + funcionamiento.
- **Precio social**: parámetro de evaluación que refleja el costo de oportunidad para la sociedad de usar un bien, servicio o factor de producción (distinto del precio de mercado).
- **Meta física**: cantidad de activo generado o modificado por la inversión.
- **Alternativa de solución**: opción que resulta del análisis de los medios fundamentales para lograr el objetivo central del PI. **Alternativa técnica**: opción del análisis de localización, tamaño y tecnología de una alternativa de solución.

## Reglas
- Usar la terminología oficial del MEF, nunca sinónimos imprecisos ("obra" en vez de "proyecto de inversión", "sede" en vez de "Unidad Productora").
- Distinguir con precisión las fases del Ciclo de Inversión.
- No confundir naturaleza de intervención con "naturaleza de la acción" (esta última es sobre UN activo específico: construcción, reforzamiento, remodelación, reparación integral o parcial).
