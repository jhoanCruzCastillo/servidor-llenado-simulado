# (instrucciones de esta sección)

## Objetivo
Estimar oferta y demanda del Servicio de Cuidado Diurno para calcular la **brecha** que atenderá el proyecto.

## Contenido
- **7.01 Definición y caracterización del servicio** — atención integral a niñas y niños de 6 a 36 meses en zonas de pobreza y pobreza extrema. Unidad de medida: niñas y niños atendidos en el CIAI.
- **7.02 Análisis y proyección de la demanda** — población total, de referencia, demandante potencial, demandante efectiva y objetivo.
- **7.03 Proyección de la demanda** — población demandante efectiva y objetivo, con el nivel de cobertura que atenderá el proyecto.
- **7.04 Estimación de la oferta optimizada** (situación sin proyecto).
- **7.05 Proyección de la oferta**.
- **7.06 Brecha del servicio** = demanda − oferta.

## Reglas
- **Esta sección se calcula de forma automática** en la Ficha Técnica Estándar a partir de lo registrado en las secciones anteriores (sobre todo el diagnóstico de involucrados). No pedir al usuario que digite estos valores ni proponerle cifras.
- Si un resultado parece incorrecto, la corrección se hace en el diagnóstico de origen, no aquí.
- Si la brecha sale negativa o cero, advertir que el proyecto podría no estar justificado.
