# Sección 5 — SECCIÓN N°05: PROBLEMA/OBJETIVO

- id de la sección (`seccion_id` de la respuesta): `659a4879-4375-4749-a6a2-67114ec16f27`
- hoja del Excel: `Problema-Objetivo`
- tablas de esta sección: 7 (carpeta `tablas/`)

Esta sección no tiene campos de texto para llenar (solo tablas).
