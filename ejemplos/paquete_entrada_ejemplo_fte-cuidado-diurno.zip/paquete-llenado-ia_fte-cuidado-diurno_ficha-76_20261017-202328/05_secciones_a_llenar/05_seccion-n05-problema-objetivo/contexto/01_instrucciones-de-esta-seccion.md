# (instrucciones de esta sección)

## Objetivo
Identificar el problema central con sus causas y efectos, definir los objetivos y plantear alternativas de solución técnicamente posibles, pertinentes y comparables.

## 5.01 Problema central
Se identifica con la técnica del **árbol de causas y efectos**. Para proyectos de CIAI el problema central suele ser uno de estos dos:
- Las niñas y niños de 6 a 36 meses **acceden a una prestación inadecuada** del Servicio de Cuidado Diurno (el CIAI existe pero opera en condiciones inadecuadas).
- Las niñas y niños de 6 a 36 meses **no acceden** al Servicio de Cuidado Diurno (no existe el CIAI).

### 5.01.01 — Indicador del problema (tabla, filas dinámicas)
Una sola fila. Describe el problema central (`descripcion_problema`), su indicador de seguimiento (`indicador`, `descripcion_indicador`), la unidad de medida (`um`, normalmente "CIAI") y el valor actual (`valor`) — el valor viene de la brecha diagnosticada en las secciones 2 y 3, no lo inventes si no hay evidencia.

### 5.01.02 — Árbol de causas (tabla jerárquica de 3 niveles)
`Causas Directas (CD)` → `Causas indirectas (CI)` → `Evidencias`. Cada CD agrupa una o más CI, y cada CI se sustenta con una evidencia (dato o cifra concreta de la fuente de la verdad o del diagnóstico de las secciones 2-4, nunca inventada). Usa 2-3 CD como máximo, cada una con 1-3 CI.

### 5.01.03 — Árbol de efectos (tabla jerárquica de 3 niveles)
`Efectos Indirectos (EI)` → `Evidencias (sustento)` → `Efectos Directos (ED)`. Ojo con el orden: el nivel raíz son los EFECTOS INDIRECTOS (la consecuencia de más alto nivel, ej. "Inadecuado desarrollo cognitivo..."), el nivel intermedio es la evidencia/sustento que lo cuantifica, y las hojas son los EFECTOS DIRECTOS (la consecuencia inmediata del problema). No confundas el nivel raíz con "evidencias" — cada nivel tiene su propio rol aunque el nombre de columna pueda sonar parecido.

## 5.02 Objetivo central
Se formula como la situación positiva que revierte el problema central (mismo texto que 5.01.01 pero en positivo). Los medios se derivan de las causas y los fines de los efectos.

### 5.02.01 — Indicador del objetivo (tabla, filas dinámicas)
Espejo de 5.01.01 pero en positivo: mismo indicador y unidad de medida, con la meta (valor objetivo) en vez del valor actual del problema.

### 5.02.02 y 5.02.04 — Medios fundamentales y acciones (dos tablas de filas dinámicas que forman UNA sola lista continua)
La ficha real divide esta lista en dos campos de tabla separados, pero conceptualmente es una sola tabla de Medios Fundamentales — **debe existir un Medio Fundamental por cada Causa Indirecta (CI) definida en el árbol de 5.01.02** (no uno por Causa Directa). Reparto:
- `5.02.02` lleva SOLO el primer Medio Fundamental (numero = 1), derivado de la primera CI del árbol, con su(s) Acción(es) concreta(s) para revertirla.
- `5.02.04` continúa la MISMA lista con el resto de Medios Fundamentales (numero = 2, 3, 4... uno por cada CI restante, en el mismo orden en que aparecen en 5.01.02).
- Nunca repitas un mismo Medio Fundamental en ambas tablas, y la columna `medio` (nombre del medio fundamental) no debe quedar vacía — descríbelo brevemente aunque el ejemplo de referencia a veces lo deje así.

### 5.02.03 — Árbol de fines (tabla jerárquica de 2 niveles)
`Fines Indirectos (FI)` → `Fines directos (FD)` — espejo en positivo del árbol de efectos de 5.01.03 (sin el nivel de evidencias intermedio).

## 5.03 Alternativas
Deben guardar relación directa con el objetivo central y ser comparables entre sí. `5.03.01` es un campo calculado por el Excel a partir de 5.01-5.02 — no se llena con IA.

## Reglas
- El problema debe redactarse como situación negativa, nunca como falta de una solución ("no hay mobiliario" no es un problema central).
- Causas y efectos deben ser consistentes con el diagnóstico del territorio, la unidad productora y los involucrados (secciones 2-4) — reutiliza esos datos, no inventes cifras nuevas.
- El número de Causas Indirectas en 5.01.02 debe coincidir con el número total de filas entre 5.02.02 y 5.02.04 (una relación 1 a 1, Medio Fundamental por Causa Indirecta).
- Los efectos (5.01.03) y fines (5.02.03) deben tener la misma cantidad de ramas raíz que causas/medios, guardando simetría causa↔efecto y medio↔fin.
