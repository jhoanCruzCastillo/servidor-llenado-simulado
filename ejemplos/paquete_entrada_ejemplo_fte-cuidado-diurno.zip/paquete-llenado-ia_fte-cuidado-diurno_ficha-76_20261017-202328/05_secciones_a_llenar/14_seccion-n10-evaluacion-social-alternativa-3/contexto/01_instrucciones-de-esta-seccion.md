# (instrucciones de esta sección)

## Objetivo
Igual estructura y reglas que la Evaluación Social de la Alternativa 1 — ver ese contexto para el detalle.

## Diferencia con las otras alternativas
Se alimenta de los **Costos del Proyecto de la Alternativa 3**. Si no existe una tercera alternativa técnica, esta sección queda sin completar.

## Reglas
- Costos sociales, flujo, indicadores y sensibilidad son cálculos automáticos — no proponer cifras a mano.
