# Sección 14 — SECCIÓN N°10: EVALUACIÓN SOCIAL - ALTERNATIVA 3

- id de la sección (`seccion_id` de la respuesta): `b19db19b-7920-4fea-b09d-8fc76a627e88`
- hoja del Excel: `Evaluación Social Alt3`
- tablas de esta sección: 1 (carpeta `tablas/`)

Esta sección no tiene campos de texto para llenar (solo tablas).
