# (instrucciones de esta sección)

## Objetivo
Analizar las características del Servicio de Cuidado Diurno que se brinda en el CIAI y el estado situacional de sus factores de producción.

## Contenido
- **3.01 Nombre del CIAI** — lo define la Unidad Territorial del PNCM.
- **3.02 Código de identificación del CIAI**.
- **3.03 Localización geográfica de la UP**.
- **3.04 Diagnóstico de procesos** de la unidad productora.
- **3.05 Diagnóstico de los activos** de la UP.

## 3.05 Diagnóstico de activos
Por cada activo estratégico se registra: servicio y procesos de producción, tipo de factor productivo, activo estratégico, **norma técnica** aplicable, si **cumple (Sí/No)** con los estándares de calidad del PNCM, y su **estado situacional**.

Un CIAI está en condición inadecuada cuando **al menos un** factor de producción no cumple la lista de condiciones de infraestructura del servicio.

## 3.06 Condiciones técnicas del local
11 preguntas de Sí/No (más 2 de texto libre al final) sobre el local donde funciona o funcionará el CIAI: distancia a peligros (agentes contaminantes, grifos, líneas de alta tensión), colindancia con establecimientos de salud, si las salas están en primer piso, orientación de las puertas respecto al tránsito vehicular, y acceso a agua/desagüe/energía eléctrica por red pública. Responde exactamente "Sí" o "No" para cada una — nunca "no aplica" ni una descripción larga, salvo que la fuente de la verdad realmente no diga nada al respecto (ahí sí déjala vacía).
Las 2 últimas (titularidad del local, situación del saneamiento físico legal) son de catálogo cerrado — usa el texto exacto de la opción que corresponda.

## 3.07 Prácticas de operación y mantenimiento (situación actual)
Dos tablas jerárquicas agrupadas: **a. Personal** (quién opera el CIAI hoy — cargos, cantidad, costo) y **b. Servicios y mantenimiento** (quién paga/mantiene el local, con qué frecuencia, a qué costo). El nodo padre de cada grupo es una descripción narrativa de la práctica actual; los hijos son el detalle con cantidad y costo (el total lo calcula el Excel, nunca lo llenes).

## 3.08 Evolución del nivel de producción
Serie histórica de los últimos 5 años (Año -5 a Año -1) de cuántas niñas/niños atendió el CIAI — normalmente viene en el mismo documento que reporta la capacidad actual/autorizada del CIAI.

## 3.09 Exposición a peligros de la Unidad Productora
Por cada peligro identificado en 2.05 (Sección 2), indicar el nivel de exposición y fragilidad del CIAI específicamente (no del área de estudio en general) y si existe un plan de contingencia (Sí/No). Si 2.05 no identificó peligros con antecedentes, esta tabla puede quedar vacía — no inventes niveles de exposición sin evidencia.

## Reglas
- Evaluar cada activo contra su norma técnica, no de forma genérica.
- Si un activo no aplica al CIAI, decirlo explícitamente en vez de marcarlo como cumplido.
- Las respuestas Sí/No de 3.06 y 3.09 deben ser exactamente "Sí" o "No", nunca variantes.
