# (instrucciones de esta sección)

## Objetivo
Igual estructura y reglas que la sección de Costos del Proyecto de la Alternativa 1 — ver ese contexto para el detalle de cada campo y sus ejemplos.

## Diferencia con las otras alternativas
Esta es la **Alternativa técnica 3**: sus montos y metas físicas deben corresponder a la tecnología descrita para esta tercera alternativa en el Análisis Técnico. La mayoría de proyectos de CIAI solo plantean 1 o 2 alternativas técnicas — si no existe una tercera, esta sección queda sin desarrollar.

## Reglas
- Nunca copiar montos de otra alternativa sin que el usuario confirme que aplican igual.
- Si el usuario no ha definido una tercera alternativa técnica, decirlo explícitamente en vez de inventarla.
