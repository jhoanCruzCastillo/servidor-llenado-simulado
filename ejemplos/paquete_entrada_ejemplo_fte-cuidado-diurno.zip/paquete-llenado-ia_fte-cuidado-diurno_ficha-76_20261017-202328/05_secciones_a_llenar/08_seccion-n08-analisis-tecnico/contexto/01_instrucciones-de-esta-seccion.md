# (instrucciones de esta sección)

## Objetivo
Definir tamaño, localización y tecnología de la intervención, identificar medidas de reducción del riesgo de desastres, resumir las alternativas técnicas planteadas y fijar las metas físicas de los activos a crear o intervenir. Este bloque se desarrolla **una vez por cada alternativa técnica propuesta** (ver el resumen de alternativas), aunque en la ficha vive como una sola sección de análisis técnico común.

## Análisis de tamaño (¿cuánto producir?)
El tamaño depende de la población objetivo y del análisis de mercado (la brecha ya calculada). Debe cumplir la Directiva "Intervención en la infraestructura de locales del servicio de cuidado diurno" y la Directiva "Parámetros de diseño para la construcción de locales..." del PNCM. El factor condicionante típico es la **meta prevista por el PNCM para el CIAI** (niñas y niños), que determina el tipo de CIAI (ej. "Tipo III-B, 60 niños y niñas") y el área mínima requerida, con y sin servicio alimentario.

## Análisis de localización (¿dónde producir?)
Se verifica el cumplimiento de las condiciones técnicas del local — todas deben cumplirse para la situación con proyecto:
- Alejado de agentes contaminantes o peligros no mitigables.
- A no menos de 50 m de estaciones de expendio de combustible.
- A no menos de 25 m de una línea de alta tensión eléctrica.
- No colindante con hospitales/centros de salud de categoría I-3, I-4, II o III.
- Puertas de ingreso/salida no orientadas directamente a una vía de alto tránsito.
- Abastecimiento de agua, desagüe y energía eléctrica con conexión a red pública.

También se registra la titularidad del local (ej. "Propiedad del Estado") y la situación del saneamiento físico legal (ej. "Caso Gobierno Regional: Resolución y/o acuerdo de consejo que aprueba la afectación o transferencia a favor del PNCM"), más la ubicación exacta (departamento, provincia, distrito, localidad y coordenadas).

## Análisis de tecnología (¿cómo producir?)
Se usa **ingeniería conceptual**. Por cada activo del CIAI (infraestructura, mobiliario, equipo, intangibles — el mismo catálogo del diagnóstico de la Unidad Productora) se indica: descripción, si se incluye o no como parte del proyecto de inversión, y la normativa aplicable (Directiva PNCM, RNE). Los activos y su descripción vienen predefinidos en la ficha; el equipo formulador solo decide inclusión y normativa.

## Identificación de medidas de reducción del riesgo de desastres
La tabla `08.04.1` viene con **exactamente 16 filas fijas, una por cada peligro del catálogo estándar** (el mismo orden y catálogo de `2.05.01` en Diagnóstico del Territorio) — nunca agregues, quites ni combines filas, ni aunque dos peligros te parezcan similares:
Inundaciones, Movimientos en masa, Lluvias intensas, Helada, Nevadas, Friaje, Sismos, Sequías, Vulcanismo, Tsunamis, Incendios forestales, Erosión, Vientos fuertes, Incendios urbanos, Radiación solar, Otros.
Para CADA una de las 16 (en ese orden): completa Exposición/Fragilidad/Resiliencia según lo ya registrado en `2.05.01` para ese peligro (si ahí no aparece o su exposición es "Bajo"/no aplica, marca lo mismo aquí — no la subas de nivel). Solo escribe una medida concreta en "Descripción de las medidas..." para los peligros con exposición **Alto o Medio** heredada de `2.05.01`; en el resto deja esa columna vacía o "No aplica", pero la FILA debe seguir presente. Ejemplos reales de medida: coberturas de techos diseñadas para altos niveles de precipitación (lluvias intensas), ambientes con materiales térmicos (heladas), elementos antisísmicos según el RNE (sismos), estructuras diseñadas para vientos fuertes.

## Resumen de las alternativas técnicas
Tamaño y localización se completan automáticamente; se debe describir la **tecnología** de cada alternativa (ej. "En el diseño del proyecto se consideran los estándares definidos en la Directiva 'Parámetros de diseño...' y en la Directiva 'Equipamiento y Dotación de Materiales...' del PNCM"). Puede haber más de una alternativa técnica — cada una se evalúa por separado en la sección de Costos y de Evaluación Social correspondiente.

## Metas físicas de los activos
Se organiza por **componente** (normalmente uno por tipo de factor productivo: Infraestructura, Equipos, Mobiliario, Intangibles), y dentro de cada uno, por acción sobre el activo (Construcción, Reposición, Adquisición, Implementación de capacidades), con unidad de medida y cantidad. Ejemplo real: Componente 1 "Infraestructura del CIAI cumple con los estándares de calidad" incluye construcción de Sala de cuidado diurno (2 salas, 100.80 m² en total), Sala de usos múltiples (2 ambientes, 90 m²), Almacén (12.50 m²), Cerco perimétrico (200 ml), etc.

## Reglas
- No inventar normativa aplicable: si el usuario no la precisa, usar "Directiva PNCM, RNE" como referencia genérica y advertir que debe verificarse.
- El área/tamaño del CIAI depende de la meta de niñas y niños definida por el PNCM — no proponer una cifra sin ese dato.
- Cada activo que "no se incluye en el PI" igual debe listarse (con su descripción), simplemente marcado como no incluido — no omitirlo de la tabla.
- Anexar (o pedir al usuario) el Informe Técnico de la Propuesta de Intervención con la opinión favorable de la UT del PNCM sobre tamaño y tecnología.
