# Sección 12 — SECCIÓN N°10: EVALUACIÓN SOCIAL - ALTERNATIVA 1

- id de la sección (`seccion_id` de la respuesta): `e295b25e-5ccf-4423-aa97-adc770ac55dd`
- hoja del Excel: `Evaluación Social Alt1`
- tablas de esta sección: 1 (carpeta `tablas/`)

Esta sección no tiene campos de texto para llenar (solo tablas).
