# (instrucciones de esta sección)

## Objetivo
Identificar, medir y valorizar los beneficios y costos de la **Alternativa técnica 1** desde el punto de vista del bienestar social del país, estimar los indicadores de rentabilidad social y hacer el análisis de sensibilidad. Con el resultado de esta evaluación (comparando todas las alternativas) se selecciona la mejor alternativa técnica.

## Beneficios sociales
Se relacionan con los fines del proyecto (los efectos que revierte el problema central). Para CIAI son siempre los mismos cinco, ya predefinidos en la ficha: mayor acceso a raciones alimentarias y suplemento con hierro; suficiente seguimiento al control CRED; adecuado desarrollo cognitivo; ingesta adecuada de nutrientes; mayor nivel de desarrollo infantil temprano en niñas y niños de 6 a 36 meses en pobreza o pobreza extrema. No se valorizan monetariamente — se listan como parte del sustento cualitativo.

## Costos sociales
Se aplican **factores de corrección** (parámetros del Anexo N° 11 del SNPMGI) a los costos de inversión y a los de operación y mantenimiento, para pasar de precio de mercado a precio social. **Esta sección se calcula automáticamente** en la ficha a partir de los Costos del Proyecto de esta misma alternativa — no pedir al usuario que digite los costos sociales a mano, solo verificar que el costo de inversión de origen esté completo.

## Flujo de costos a precios sociales
Se arma con los costos de inversión, reinversión y operación/mantenimiento incremental (con proyecto menos sin proyecto) a precios sociales, año por año, a lo largo de todo el horizonte de evaluación. Incluye el valor de recuperación de la inversión en infraestructura (10%) en el último año.

## Indicadores de rentabilidad social
Para CIAI se usa la metodología **costo-eficacia** (no costo-beneficio, porque valorizar monetariamente los beneficios es muy complejo). El indicador es el ratio **costo-eficacia (CE)**: Valor Actual de los Costos Sociales (VACS) entre el total de niñas y niños de 6 a 36 meses que accederán al servicio (población objetivo) en todo el horizonte. **Se calcula automáticamente.**

## Análisis de sensibilidad
Matriz bidimensional que muestra cómo varía el índice costo-eficacia ante cambios porcentuales simultáneos en los costos del proyecto (eje columnas, ej. -20% a +20%) y en el total de beneficiarios (eje filas). Se genera automáticamente a partir de los datos ya registrados.

## Reglas
- Costos sociales, flujo, indicadores y sensibilidad son **cálculos automáticos** de la ficha — no se le pide al usuario que los calcule ni se le proponen cifras; solo se verifica que los insumos (costos de inversión, O&M, horizonte) estén completos.
- Esta evaluación corresponde a la Alternativa 1 — debe alimentarse de los Costos del Proyecto de esa misma alternativa, no de otra.
