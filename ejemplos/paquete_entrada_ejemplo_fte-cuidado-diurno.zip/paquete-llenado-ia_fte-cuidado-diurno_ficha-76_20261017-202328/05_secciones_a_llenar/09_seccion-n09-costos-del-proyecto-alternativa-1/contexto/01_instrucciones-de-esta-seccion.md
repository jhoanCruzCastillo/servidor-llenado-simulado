# (instrucciones de esta sección)

## Objetivo
Estimar, a precios de mercado, los costos de la **Alternativa técnica 1**: costo de ejecución física, reinversiones, operación y mantenimiento, y los cronogramas de inversión (financiero y físico).

## Costo de ejecución física de las acciones
Por cada **componente** (uno por tipo de factor productivo: Infraestructura, Equipos, Mobiliario, Intangibles) se detalla: acción sobre el activo, tipo de factor productivo, activo, unidad de medida y cantidad (unidad física y, para infraestructura, dimensión física en m²/ml), costo unitario y costo total. Esto es el **costo directo**. Ejemplo real: Componente 1 "Infraestructura del CIAI cumple con los estándares de calidad" — Sala de cuidado diurno (2 salas, 100.80 m², S/ 3,650/m², S/ 367,920), Ambiente de recreación activa (90 m², S/ 328,500), Almacén (60.48 m², S/ 220,752), Cerco perimétrico (200 ml, S/ 550/ml, S/ 110,000).

**Mapeo fijo campo → componente** (no lo adivines ni lo desplaces): `09.01.1` y `09.01.2` son las dos partes de Componente 1 = Infraestructura (misma fuente que `08.06.1`); `09.01.3` = Componente 2 = Equipos (misma fuente que `08.06.2`); `09.01.4` = Componente 3 = Mobiliario (misma fuente que `08.06.3`); `09.01.5` = Componente 4 = Intangibles (misma fuente que `08.06.4`). Cada uno se llena con los activos de SU propio componente en Análisis Técnico — nunca muevas el contenido de un componente al campo de otro componente aunque uno de ellos parezca tener más información disponible. Si la fuente da un solo monto conjunto para "mobiliario y equipos" (sin desglosar cuánto es de cada uno), ponlo UNA sola vez en el componente que mejor le corresponda (Equipos) y deja el otro campo (Mobiliario) vacío — nunca repitas el mismo monto en dos componentes, aunque eso signifique dejar uno sin llenar.

Además de los componentes, se suman **costos indirectos**: Gestión del proyecto, Expediente técnico o documento equivalente, Supervisión, Liquidación, Gastos generales — cada uno como monto y como % del costo directo. En el ejemplo oficial: Gestión del proyecto S/ 65,000 (5.0%), Expediente técnico S/ 89,700 (6.8%), Supervisión S/ 50,000 (3.8%), Liquidación S/ 30,000 (2.3%), Gastos generales S/ 150,000 (11.4%) — subtotal de otros costos S/ 384,700, costo total de inversión ≈ S/ 1,696,055 (varía según qué componentes se incluyan).

## Costos de reinversión
Activos cuya vida útil termina dentro del horizonte de evaluación (típicamente mobiliario y equipos, no la infraestructura). Se identifica el activo, su unidad de medida, cantidad, y en qué año del horizonte se reemplaza, con su costo proyectado (puede ajustarse por inflación). Ejemplo: reposición de mobiliario de sala de cuidado diurno (35 unidades) programada varios años después de la puesta en marcha.

## Costos de operación y mantenimiento con y sin proyecto
Se registra primero la fecha prevista de inicio de operaciones y el horizonte de funcionamiento (años — normalmente 10). La situación **sin proyecto** ya viene cargada automáticamente desde el diagnóstico; el equipo formulador solo completa la situación **con proyecto**: personal (actores comunales — madre cuidadora, madre guía, guía de familia, socia de cocina, repartidor, apoyo de limpieza y vigilancia — y equipo técnico del PNCM — acompañantes técnicos, especialistas integrales, especialistas en nutrición) y servicios (agua, luz, internet, seguridad, mantenimiento).

## Cronograma de inversión de metas financieras
Se define fecha prevista de inicio de ejecución, tipo de periodo (normalmente trimestre) y número de periodos. Cada componente y los costos indirectos se distribuyen en el cronograma trimestral según cuándo se ejecuta cada uno, con su costo estimado a precios de mercado. Incluye el "Control concurrente" (hasta el 2% del costo total de inversión).

## Cronograma de metas físicas
En base al cronograma financiero, se distribuyen en el tiempo las metas físicas de cada componente (m² construidos, número de equipos, número de mobiliario, número de eventos de capacitación), trimestre a trimestre, hasta llegar a la meta física total.

## Reglas
- Esta es la **Alternativa 1** — sus costos deben corresponder a la tecnología y metas físicas descritas para esta alternativa en el Análisis Técnico, no a otra alternativa.
- No inventar costos unitarios: si el usuario no los da, pedirlos o usar el ejemplo oficial como referencia solo para ilustrar el formato, dejándolo explícito.
- Verificar que el costo total de inversión del cronograma financiero coincida con el de la sección de costo de ejecución física.
