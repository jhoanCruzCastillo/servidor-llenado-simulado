# (instrucciones de esta sección)

## Objetivo
Planear, ejecutar, supervisar y controlar la implementación de los componentes del proyecto. **Se desarrolla solo para la alternativa seleccionada** en la Evaluación Social.

## Plan de implementación
Detalla actividades y tareas con secuencia, ruta crítica, duración, responsable y recursos — considerando un escenario realista de plazos de contratación. Estructura típica: Expediente Técnico o Estudio Definitivo (elaboración), Supervisión (de la ejecución), Ejecución (una fila por componente: Infraestructura, Equipos, Mobiliario, Capacidades), cada uno con fecha de inicio, fecha de fin, órgano responsable (ej. "PNCM - UT Cusco") y en qué periodo/trimestre ocurre.

## Modalidad de ejecución de proyecto
Una sola opción entre las cinco oficiales: Administración directa, Administración indirecta – por contrata, Administración indirecta – Asociación Público Privado (APP), Administración indirecta – Núcleo Ejecutor, Administración indirecta – Ley 29230 (Obras por Impuestos).

## Requerimientos institucionales y normativos en la fase de Ejecución y de Funcionamiento
Se marca el estado situacional de cada condición previa relevante: saneamiento técnico legal o arreglo institucional, factibilidad de servicios de agua/desagüe/electricidad, certificado de parámetros urbanísticos, licencia de construcción — indicando si ya se cuenta con ella o cuándo se tramitará (ej. "se tramitará durante la elaboración del Expediente Técnico").

## Entidad a cargo de la operación y mantenimiento
Para esta tipología, siempre el **Programa Nacional Cuna Más**.

## Fuente de financiamiento
Una sola opción entre las cinco oficiales: Recursos ordinarios, Recursos directamente recaudados, Recursos por operaciones oficiales de crédito, Donaciones y transferencias, Recursos determinados.

## Reglas
- La modalidad de ejecución y la fuente de financiamiento son selección única entre las opciones oficiales — no inventar una modalidad ni fuente distinta.
- El plan de implementación debe ser coherente con el cronograma de inversión de la alternativa seleccionada (mismas fechas y componentes).
