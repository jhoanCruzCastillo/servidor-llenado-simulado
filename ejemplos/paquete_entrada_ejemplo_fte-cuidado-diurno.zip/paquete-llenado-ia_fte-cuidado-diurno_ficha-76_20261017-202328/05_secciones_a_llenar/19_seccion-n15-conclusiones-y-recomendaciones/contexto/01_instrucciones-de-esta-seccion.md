# (instrucciones de esta sección)

## Objetivo
Indicar el resultado del proceso de formulación y evaluación del proyecto — **viable o no viable** — y sustentarlo.

## Qué debe contener
a. Precisar y sustentar cuál de las alternativas técnicas propuestas es la seleccionada (normalmente la de mejor ratio costo-eficacia en la Evaluación Social).
b. Sustentar el cumplimiento de los tres atributos que definen la viabilidad de un proyecto de inversión (si es viable); si no lo es, indicar qué atributo(s) no se cumplió.
c. Emitir un juicio técnico sobre la calidad y pertinencia del nivel de profundización de la información empleada, y la consistencia de los supuestos, fuentes, normas técnicas, parámetros y metodologías usadas en toda la ficha.

## Reglas
- La alternativa que se declara seleccionada aquí debe ser la misma que se usó para Sostenibilidad, Gestión del Proyecto, Impacto Ambiental y Marco Lógico — verificar coherencia antes de cerrar la ficha.
- No declarar "viable" sin que los tres atributos estén efectivamente sustentados en las secciones anteriores.
