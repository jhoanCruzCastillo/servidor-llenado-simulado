# (instrucciones de esta sección)

## Objetivo
Definir el horizonte de evaluación para determinar el flujo de costos y beneficiarios sujetos a evaluación.

## Composición
El horizonte comprende **fase de Ejecución + fase de Funcionamiento**.

- **Fase de Ejecución**: tiempo previsto para elaborar el expediente técnico o documento equivalente y para la ejecución física. Se definen fechas de inicio y fin de cada momento, incluidos los plazos de los **procesos de contratación** (tanto del expediente técnico como de la ejecución física).
- **Fase de Funcionamiento**: **10 años**, tiempo esperado durante el cual el CIAI brinda el servicio conforme a las normas técnicas del PNCM.

## Reglas
- La fase de funcionamiento es 10 años salvo justificación expresa.
- El total del horizonte es la suma de ambas fases; el Excel lo calcula solo, no sobrescribirlo.
- Las fechas deben ser coherentes entre sí: viabilidad → contratación → expediente → ejecución → funcionamiento.
