# Finanzas

## Criterios financieros
- Los montos van en soles (S/) y a precios de mercado, salvo que la sección pida precios sociales.
- Verificar consistencia entre el costo de inversión, el cronograma y los costos de operación y mantenimiento.

## Reglas
- No redondear cifras oficiales.
- Si un monto no cuadra con su desagregado, advertirlo en vez de corregirlo por cuenta propia.
