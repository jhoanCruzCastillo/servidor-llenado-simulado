# (instrucciones de esta sección)

## Objetivo
Describir y caracterizar a la población afectada, e identificar a los involucrados, su percepción, expectativas y nivel de participación.

## 4.01 Población afectada
Conjunto de personas afectadas por la problemática del Servicio de Cuidado Diurno, sea por falta de acceso (**cobertura**) o por recibirlo de forma inadecuada (**calidad**). Tabla agrupada por tipo de población (población total del área de influencia, población de referencia 6-36 meses, demandante potencial, demandante efectiva, población objetivo) — cada fila trae descripción, unidad de medida, cantidad y %.

Grupos de análisis:
- **Población total**: población de los distritos del área de influencia. Fuente: **INEI**.
- **Población de referencia**: la parte de la población total dentro del grupo etario de **6 a 36 meses** que podría recibir el servicio, aplicando los criterios de focalización del PNCM.
- **Población demandante potencial**, **demandante efectiva** y **población objetivo**.

## 4.02 Caracterización de la población demandante potencial
Desagregación de los niños y niñas de la población demandante potencial (4.01) por variable/indicador (ej. edad, sexo, condición socioeconómica) y categoría dentro de esa variable (ej. "de 6 a 12 meses", "de 13 a 24 meses") — cantidad de niños, cantidad de niñas, % respecto a la población demandante efectiva, y fuente. Debe ser consistente con los totales de 4.01: la suma de categorías de una misma variable no debería superponerse ni exceder la población demandante potencial reportada ahí.

## 4.03 Matriz de involucrados
Registrar por cada actor: grupo, posición (a favor/cooperante/opositor), problemas percibidos, intereses, estrategias y acuerdos o compromisos.

## Reglas
- Toda cifra poblacional debe indicar fuente y año.
- Mantener la coherencia de estos grupos con el Análisis de Mercado: esa sección se calcula a partir de ellos.
- No inventes cifras de 4.02 que no aparezcan (ni se puedan derivar con una sola operación simple) en la fuente de la verdad — mejor dejar la fila vacía que una cifra inventada que "cuadre" con el total.
