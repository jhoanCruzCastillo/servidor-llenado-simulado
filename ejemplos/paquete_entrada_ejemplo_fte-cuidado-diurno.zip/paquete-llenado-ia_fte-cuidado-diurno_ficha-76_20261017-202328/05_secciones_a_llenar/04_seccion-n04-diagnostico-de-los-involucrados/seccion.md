# Sección 4 — SECCIÓN N°04: DIAGNÓSTICO DE LOS INVOLUCRADOS

- id de la sección (`seccion_id` de la respuesta): `dcb56473-53d9-4e10-aed7-b2a7b82a74bf`
- hoja del Excel: `Involucrados`
- tablas de esta sección: 3 (carpeta `tablas/`)

Esta sección no tiene campos de texto para llenar (solo tablas).
