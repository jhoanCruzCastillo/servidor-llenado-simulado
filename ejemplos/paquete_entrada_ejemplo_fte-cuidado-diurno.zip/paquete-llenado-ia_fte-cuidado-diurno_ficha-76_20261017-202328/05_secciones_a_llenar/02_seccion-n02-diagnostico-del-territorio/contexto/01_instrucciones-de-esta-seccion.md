# (instrucciones de esta sección)

## Objetivo
Analizar el ámbito geográfico donde se ubican la población afectada y la unidad productora: área de estudio, área de influencia, macro y microlocalización, características del distrito y peligros.

## 2.01 Área de estudio
Es el área donde vive la población afectada (niñas y niños de 6 a 36 meses que demandan el servicio) **y** donde se ubica el CIAI a intervenir. Se precisa: localidad o centro poblado, distrito(s) con su **UBIGEO**, provincia y departamento.

## 2.02 Área de influencia
Espacio geográfico donde se ubica la población que demanda el servicio. Puede abarcar uno o más centros poblados, distritos o incluso provincias.

Debe enmarcarse en el **ámbito de intervención focalizada del PNCM**, que se circunscribe a distritos que cumplen al menos uno de estos criterios:
- Centros poblados urbanos de quintil 1 al 4 en departamentos con pobreza departamental mayor a 30.1%, con familias económicamente activas.
- Centros poblados urbanos de quintil 1 al 3 en departamentos con menor pobreza departamental.

## 2.03 Macro y microlocalización del área de estudio
- Los mapas de macrolocalización y microlocalización (imágenes) los sube el usuario manualmente — la IA no los toca.
- **Fuente de información**: cita las fuentes cartográficas usadas para elaborar los mapas (ej. INEI — planos censales, Google Earth Pro, catastro municipal, IGN). Si la fuente de la verdad no lo menciona explícitamente, déjala vacía — no inventes una fuente genérica.

## 2.04 Características del distrito donde se ubica o ubicará el CIAI
Datos físicos, climáticos y socioeconómicos del distrito, normalmente disponibles en el diagnóstico territorial de la fuente de la verdad:
- **Altitud** (m.s.n.m.), **Temperatura media anual**, **Humedad**, **Precipitación media anual**: cifras puntuales — cópialas tal como aparecen (con su unidad) en la fuente; no las inventes ni las redondees.
- **Coordenadas geográficas** (latitud/longitud en decimales): del predio o centro poblado donde se ubica/ubicará el CIAI.
- **Accesibilidad**: cómo se llega al distrito/predio (vías, tiempo de viaje, medios de transporte).
- **Condiciones de pobreza**: cifras de pobreza monetaria/no monetaria del distrito, citando fuente y año (ej. Mapa de Pobreza INEI).
- **Principales características sociales y económicas**: actividades económicas predominantes, situación de la población objetivo (niñez, familias).
- **Acceso a servicios públicos en el distrito** (tabla): porcentaje de acceso a agua, desagüe, electricidad u otros servicios — usa las cifras que traiga la fuente de la verdad, normalmente de un censo o diagnóstico similar.

## 2.05 Peligros
Identificar antecedentes de ocurrencia en el área de estudio y posibles cambios futuros, con sus características (intensidad, frecuencia, área de impacto).
Peligros a evaluar: inundaciones, movimientos en masa, lluvias intensas, heladas, nevadas, sismos, sequías, vulcanismo, tsunamis, incendios forestales y urbanos, erosión, vientos fuertes, friaje, radiación solar.
Fuente recomendada: **SIGRID – CENEPRED** (https://sigrid.cenepred.gob.pe/sigridv3/).

## Reglas
- El UBIGEO es obligatorio y determina departamento, provincia y distrito: no contradecirlo.
- Toda cifra de pobreza, población o característica del distrito debe citar fuente y año si la fuente de la verdad la trae.
- No inventes cifras climáticas, de accesibilidad o de acceso a servicios que no estén en la fuente de la verdad: si no aparecen, deja el campo vacío.
