# Sociales

## Enfoque social
- Caracterizar la población afectada con datos verificables (INEI, censos, encuestas propias fechadas).
- Incluir enfoque de género e interculturalidad cuando la población lo amerite.

## Reglas
- Toda cifra poblacional debe citar su fuente y su año.
