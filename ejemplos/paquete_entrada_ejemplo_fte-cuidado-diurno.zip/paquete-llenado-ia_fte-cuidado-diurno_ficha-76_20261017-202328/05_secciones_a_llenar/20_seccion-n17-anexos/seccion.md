# Sección 20 — SECCIÓN N°17: ANEXOS

- id de la sección (`seccion_id` de la respuesta): `0c74f444-2454-4682-b5a8-009e2e8cc37a`
- hoja del Excel: `Anexos`
- tablas de esta sección: 1 (carpeta `tablas/`)

Esta sección no tiene campos de texto para llenar (solo tablas).
