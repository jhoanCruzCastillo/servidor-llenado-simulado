# Sección 10 — SECCIÓN N°09: COSTOS DEL PROYECTO - ALTERNATIVA 2

- id de la sección (`seccion_id` de la respuesta): `95aad77c-fe9a-4e3a-949c-b1ac6af83aab`
- hoja del Excel: `CostosAlt2`
- tablas de esta sección: 12 (carpeta `tablas/`)

## Campos de esta sección y cómo llenarlos

Llena los campos de la sección "SECCIÓN N°09: COSTOS DEL PROYECTO - ALTERNATIVA 2" (seccion_id: 95aad77c-fe9a-4e3a-949c-b1ac6af83aab) según la fuente de la verdad.
Devuelve el JSON con el arreglo "campos" usando los identificadores listados abajo.
Valores YA CONFIRMADOS en otras secciones de esta misma ficha — mantente consistente con esto (mismo nombre de entidad, mismo CIAI, mismo UBIGEO si aplica, etc.), no los repitas como si fueran nuevos:
- 1.02.01: 23 PROTECCIÓN SOCIAL
- 1.02.02: 051 ASISTENCIA SOCIAL
- 1.02.03: 0115 PROTECCIÓN DE POBLACIONES EN RIESGO
- 1.02.04: DESARROLLO E INCLUSION SOCIAL
- 1.02.05: CENTRO INFANTIL DE ATENCIÓN INTEGRAL
- 2.03.02: Leyenda

Mapa de macrolocalización del CIAI de la localidad/centro poblado de San Antonio, del distrito de San Sebastian, provincia de Cusco, departamento de Cusco
- 2.03.04: Leyenda

Mapa de microlocalización del CIAI de la localidad/centro poblado de San Antonio, del distrito de San Sebastian, provincia de Cusco, departamento de Cusco
- 6.01.11:  11.59
- 6.01.12:  1.59
- 6.01.13:  10.00
- 7.01.01: El Servicio de Cuidado Diuirno consiste en brindar atención integral a niños entre 6 y 36 meses de edad, que viven en zonas de pobreza y pobreza extrema, y requieren de atención en sus necesidades básicas de salud, nutrición, seguridad, protección, afecto, descanso, juego, aprendizaje y desarrollo de habilidades. Comprende:

- Aprendizaje Infantil: Cuidado y Juego.
- Promoción de prácticas en el cuidado de la salud en la niña o niño.
- Atención alimentaria y nutricional.
- Fortalecimiento de prácticas de cuidado saludable y aprendizaje en la familia usuaria.

La unidad de medida del servicio es: niños y niñas atendidos en el CIAI
- 7.02.02: Población Total: es la población total del área de influencia definida en el diagnóstico. 

Población de Referencia: es la proporción de la población total, vinculada con el objetivo central del proyecto de inversión, es decir, que está dentro del grupo etario que podría recibir el Servicio de Cuidado Diurno.

Población Demandante Potencial: es el segmento de la población de referencia, que es afectada por el problema central, que no accede al Servicio de Cuidado Diurno o accede de forma inadecuada. 

Población Demandante Efectiva: es el segmento de la población demandante potencial que cumple con los criterios de focalización definidos por el Sector para acceder al Servicio de Cuidado Diurno, en un CIAI.

Población Objetivo: es aquella parte de la población demandante efectiva que el proyecto  está en condiciones de atender de forma integral en un CIAI, considerando la política de focalización del Sector y la definición de la meta correspondiente. Es definida por el Programa Nacional Cuna Más.
- 09.03.2: 10
- 09.04.2: Trimestre
- 11.03.2: 10
- 11.04.2: Trimestre
- 16.02.1: Administración directa
- 16.04.1: Programa Nacional Cuna Más
- 1.01.01: Gobierno Nacional
- 1.01.02: Programa Nacional Cuna Más
- 1.01.03: Unidad Formuladora Programa Nacional Cuna Más
- 1.01.04: Juan Perez
- 1.01.05: Gobierno Nacional
- 1.01.06: Programa Nacional Cuna Más
- 1.01.07: UEI Cuna Más
- 1.01.08: Carlos Perez
- 1.03.01: Mejoramiento
- 1.03.02: del Servicio de Cuidado Infantil en el Centro Infantil de Atención Integral (CIAI)
- 1.03.03: en la localidad de San Antonio, distrito de San Sebastian, provincia de Cusco, departamento de Cusco
- 1.04.01: Servicio de cuidado diurno
- 1.04.02: Porcentaje de centros infantiles de atención integral que brindan el servicio de cuidado integral en condición inadecuada. (PCIAICI)
- 1.04.03: Centro Infantil de Atención Integral (CIAI)
- 1.04.04: Distrito de San Sebastian
- 1.04.05: 2026
- 1.04.06: 60%
- 1.04.07: 1
- 2.03.03: https://res.cloudinary.com/dbtb20o97/image/upload/v1789870711/proyecta-facil/imagenes/2.03.03_u2buu8.png
- 2.04.1: 3295
- 2.04.02: 12° C
- 2.04.03: 0%
- 2.04.04: 3 mm
- 2.04.06: 
El territorio de este distrito se extiende en 89,44 kilómetros cuadrados y se encuentra dentro del conurbano de la ciudad de Cuzco. Se encuentra localizado a 13º 31’ 49” Latitud Sur y 71º 56’ 14” Longitud Oeste. Se encuentra a 15 mitutos del centro de la ciudad de Cusco. Las vías de acceso son asfaltadas, se encuentran en buen estado."																				
- 2.04.07: 
En el distrito aún existe una exclusión social que genera pobreza monetaria en la población principalmente del área rural y zonas periurbanas de expansión, donde la población tiene carencias, ello está condicionado a las limitadas oportunidades de desarrollo que brindan las autoridades, como la calidad educativa que se brinda, el nivel educativo que tiene la población, limitadas oportunidades laborales, servicios de salud integrales que garanticen la esperanza de vida. El distrito de San Sebastián alcanza al año 2019 un Índice de Desarrollo Humano IDH de 0,6806, lo que significa que el nivel de desarrollo humano en el distrito se encuentra en nivel medio.
Fuente: Plan de Desarrollo Concertado MD San Sebastián al 2033
- 2.04.08: 
La vulnerabilidad de los derechos de los niños, niñas y adolescentes es un problema que podrían deberse a las limitadas acciones la disfunción familiar, entorno familiar desfavorable y el limitado sistema de protección de las niñas, niños y adolescentes por las instancias que velan por sus derechos esta es ocasionado por los propios padres por múltiples factores como discusiones, disfunciones; así como por personas extrañas que violenta, vulneran sus derechos y dañan su integridad afectando el desarrollo integral, socioemocional y su desarrollo en el futuro como ciudadano, así mismo las instancias que velan por sus derechos no protegen adecuadamente permitiendo la persistencia e incremento de la vulneración de sus derechos. para su reducción se debe promover acciones multisectoriales desde la educación, salud, seguridad y fortalecer las instancias que velan por los derechos de los niños, niñas y adolescentes.
Fuente: Plan de Desarrollo Concertado MD San Sebastián al 2033
- 3.01.01: CIAI San Antonio
- 3.02.01: 987654
- 3.06.1: Sí
- 3.06.02: Sí
- 3.06.03: Sí
- 3.06.04: No
- 3.06.05: Sí
- 3.06.06: No
- 3.06.07: Sí
- 3.06.08: Sí
- 3.06.09: Sí
- 3.06.10: Propiedad del Estado
- 3.06.11: Caso Gobierno Regional: Resolución y/o acuerdo de consejo que aprueba la afectación a favor o transferencia a favor del PNCM 
- 5.03.01: Acción 1.1.2  Reforzamiento de infraestructura del CIAI, que cumpla con los estándares de calidad, , , , Acción 1.2.1 Adquisición y/o reposición de equipos para el CIAI, de acuerdo a los estándares definidos por el PNCM., Acción 1.3.1 Adquisición y/o reposición de mobiliario para el CIAI, de acuerdo a los estándares definidos por el PNCM., Acción 2.1.1  Implementación de capacidades humanas a los actores comunitarios que operan el CIAI, 
- 6.01.01: 2024-03-23
- 6.01.02: 2024-03-28
- 6.01.03: 2024-05-27
- 6.01.04: 2024-05-28
- 6.01.05: 2024-10-25
- 6.01.06: 2024-10-30
- 6.01.07: 2025-01-28
- 6.01.08: 2025-02-02
- 6.01.09: 2025-10-30
- 6.01.10: 2025-11-04
- 08.01.2: Tipo III-B
- 08.02.1: Cumple
- 08.02.2: Cumple
- 08.02.3: Cumple
- 08.02.4: Cumple
- 08.02.5: Cumple
- 08.02.6: Cumple
- 08.02.7: Cumple
- 08.02.8: Cumple
- 08.02.9: Propiedad del Estado
- 08.02.10: Caso Gobierno Regional: Resolución y/o acuerdo de consejo que aprueba la afectación a favor o transferencia a favor del PNCM 
- 09.01.7: S/ 384,700
- 09.01.8: S/ 1,696,055.00
- 09.03.1: 2025-11-04
- 09.03.4: S/ 274,780
- 09.03.6: S/ 307,496
- 09.04.1: 2024-05-28
- 09.04.5: S/ 1,311,355
- 09.04.7:   384,700
- 09.04.8:   1,696,055
- 09.04.9:   33,921
- 10.01.6: S/ 0.00
- 10.01.8: S/ 0
- 10.01.9: S/ 0.00
- 10.03.1: 2025-11-04
- 10.03.4: S/ 274,780
- 10.03.6: S/ 0
- 10.04.1: 2024-05-28
- 10.04.5: S/ 0
- 10.04.7:   0
- 10.04.8:   0
- 11.01.6: S/ 0.00
- 11.01.8: S/ 0
- 11.01.9: S/ 0.00
- 11.03.1: 2025-11-04
- 11.03.4: S/ 274,780
- 11.03.6: S/ 0
- 11.04.1: 2024-05-28
- 11.04.5: S/ 0
- 11.04.7:   0
- 11.04.8:   0
- 16.05.1: Recursos ordinarios
Campos disponibles:
- 10.03.2 — "Horizonte de funcionamiento (años)" (tipo: decimal) — escribe el número SIN separador de miles (ej. "2450", nunca "2,450" ni "2.450"); si de verdad necesitas decimales, usa punto (ej. "2450.5"). — Horizonte de funcionamiento en años: 10 para proyectos de CIAI (se corresponde con 6.01.13). Solo el número. — ejemplo de referencia (OTRO proyecto ya resuelto, NO copiar literal, solo la forma/estilo): "10"
- 10.04.2 — "Tipo de periodo" (tipo: texto_corto) — Tipo de periodo del cronograma de inversión. Para la FTE: "Trimestre". — ejemplo de referencia (OTRO proyecto ya resuelto, NO copiar literal, solo la forma/estilo): "Trimestre"
- 10.04.3 — "Número de periodos" (tipo: decimal) — escribe el número SIN separador de miles (ej. "2450", nunca "2,450" ni "2.450"); si de verdad necesitas decimales, usa punto (ej. "2450.5"). — Número de periodos (trimestres) en que se ejecuta la inversión. Solo el número, hasta 8. Ejemplo: "8".
- 10.04.9 — "Control concurrente" (tipo: decimal) — escribe el número SIN separador de miles (ej. "2450", nunca "2,450" ni "2.450"); si de verdad necesitas decimales, usa punto (ej. "2450.5"). — Monto del control concurrente en soles (hasta el 2% del costo total de inversión). Solo el valor numérico, sin separador de miles. Si no aplica, 0.
