# (instrucciones de esta sección)

## Objetivo
Igual estructura y reglas que la sección de Costos del Proyecto de la Alternativa 1 (costo de ejecución física por componente, costos indirectos, reinversión, operación y mantenimiento, cronograma financiero y cronograma físico) — ver ese contexto para el detalle de cada campo y sus ejemplos.

## Diferencia con la Alternativa 1
Esta es la **Alternativa técnica 2**: sus montos y metas físicas deben corresponder a la tecnología descrita para esta segunda alternativa en el Análisis Técnico (Resumen de las alternativas técnicas). Si el proyecto solo tiene una alternativa técnica real, esta sección puede quedar sin desarrollar — no rellenarla copiando los valores de la Alternativa 1.

## Reglas
- Nunca copiar montos de otra alternativa sin que el usuario confirme que aplican igual.
- Si el usuario no ha definido una segunda alternativa técnica, decirlo explícitamente en vez de inventar una.
