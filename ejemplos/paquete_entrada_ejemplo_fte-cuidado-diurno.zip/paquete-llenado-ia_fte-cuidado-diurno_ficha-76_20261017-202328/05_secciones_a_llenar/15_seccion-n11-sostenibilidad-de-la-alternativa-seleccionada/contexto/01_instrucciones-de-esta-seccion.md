# (instrucciones de esta sección)

## Objetivo
Analizar la capacidad del proyecto para producir el Servicio de Cuidado Diurno de manera ininterrumpida durante todo el horizonte de evaluación. **Se desarrolla solo para la alternativa que resultó seleccionada en la Evaluación Social** (la de mejor costo-eficacia), no para todas.

## Descripción de la capacidad institucional en la sostenibilidad del proyecto
Se describen tres aspectos, cada uno con su documento de opinión favorable: (1) el **órgano técnico responsable** de la operación y mantenimiento del CIAI — para esta tipología siempre es el PNCM; (2) el **análisis de disponibilidad oportuna de recursos** para operación y mantenimiento; (3) los **arreglos institucionales** para la fase de Funcionamiento (ej. un convenio entre el PNCM y la municipalidad distrital donde se ubica el CIAI).

## Gestión integral de los riesgos
Se identifican los riesgos que pueden afectar al proyecto en Ejecución y Funcionamiento, con su probabilidad de ocurrencia y nivel de impacto (escala: Muy Alta/Alta/Moderada/Baja/Muy Baja de probabilidad × Muy Bajo/Bajo/Moderado/Alto/Muy Alto de impacto, adaptada de PMBOK), el nivel de riesgo resultante (probabilidad × impacto) y la medida de mitigación. Los riesgos típicos de esta tipología, ya predefinidos: (A) saneamiento físico legal o arreglo institucional pendiente; (B) los activos tendrán más de una ubicación; (C) impactos ambientales o conflictos sociales del proyecto; (D) la UEI propuesta no tiene experiencia en esta tipología; (E) modalidad de ejecución por núcleos ejecutores; (F) exposición a peligros naturales/socionaturales/antrópicos; (G) ubicación en zonas arqueológicas o patrimonio cultural; (H) interferencias con redes de agua, desagüe, gas o telefonía.

## Reglas
- No desarrollar esta sección para todas las alternativas — solo para la seleccionada.
- El órgano responsable de operación y mantenimiento de un CIAI es siempre el PNCM; no proponer otra entidad salvo que el usuario lo indique explícitamente.
- Cada riesgo necesita su medida de mitigación — no dejarlo solo con la probabilidad/impacto sin proponer qué hacer al respecto.
