# Sección 15 — SECCIÓN N°11: SOSTENIBILIDAD (de la alternativa seleccionada)

- id de la sección (`seccion_id` de la respuesta): `27d5811e-1614-4e73-9144-5248b8dce452`
- hoja del Excel: `Sostenibilidad`
- tablas de esta sección: 2 (carpeta `tablas/`)

Esta sección no tiene campos de texto para llenar (solo tablas).
