# Sección 13 — SECCIÓN N°10: EVALUACIÓN SOCIAL - ALTERNATIVA 2

- id de la sección (`seccion_id` de la respuesta): `a0e06ca0-f0c6-4a11-8b77-77710c3d4fde`
- hoja del Excel: `Evaluación Social Alt2`
- tablas de esta sección: 1 (carpeta `tablas/`)

Esta sección no tiene campos de texto para llenar (solo tablas).
