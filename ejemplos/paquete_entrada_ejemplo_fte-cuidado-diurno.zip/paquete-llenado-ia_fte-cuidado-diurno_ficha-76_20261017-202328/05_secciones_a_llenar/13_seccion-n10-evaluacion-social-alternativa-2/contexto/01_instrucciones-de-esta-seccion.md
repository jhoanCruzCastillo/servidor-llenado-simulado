# (instrucciones de esta sección)

## Objetivo
Igual estructura y reglas que la Evaluación Social de la Alternativa 1 (beneficios sociales, costos sociales, flujo a precios sociales, indicadores costo-eficacia calculados automáticamente, análisis de sensibilidad) — ver ese contexto para el detalle.

## Diferencia con la Alternativa 1
Se alimenta de los **Costos del Proyecto de la Alternativa 2**, no de la Alternativa 1. Si esa segunda alternativa técnica no se desarrolló, esta sección queda sin completar — no debe rellenarse con los resultados de la Alternativa 1.

## Reglas
- Costos sociales, flujo, indicadores y sensibilidad son cálculos automáticos — no proponer cifras a mano.
- Al final, la alternativa con mejor ratio costo-eficacia (menor costo por beneficiario) es la que normalmente se selecciona para Sostenibilidad, Gestión, Impacto Ambiental y Marco Lógico.
