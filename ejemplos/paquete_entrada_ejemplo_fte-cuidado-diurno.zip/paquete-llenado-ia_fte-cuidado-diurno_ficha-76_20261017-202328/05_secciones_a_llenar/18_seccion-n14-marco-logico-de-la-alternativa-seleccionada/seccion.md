# Sección 18 — SECCIÓN N°14: MARCO LÓGICO (de la alternativa seleccionada)

- id de la sección (`seccion_id` de la respuesta): `7373e39b-5c11-4224-9c15-55d2e4e02878`
- hoja del Excel: `Marco Lógico`
- tablas de esta sección: 1 (carpeta `tablas/`)

Esta sección no tiene campos de texto para llenar (solo tablas).
