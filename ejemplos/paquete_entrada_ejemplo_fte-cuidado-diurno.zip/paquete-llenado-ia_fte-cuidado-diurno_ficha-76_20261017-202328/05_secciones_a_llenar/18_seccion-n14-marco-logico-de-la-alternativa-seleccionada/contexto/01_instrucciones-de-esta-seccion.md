# (instrucciones de esta sección)

## Objetivo
Construir el Marco Lógico: la herramienta que resume la coherencia y consistencia del proyecto, a partir del árbol de objetivos y las acciones para lograr los medios fundamentales. **Se desarrolla para la alternativa seleccionada en la Evaluación Social**, y la columna de objetivos debe ser consistente con lo ya definido en Problema/Objetivo y en Costos del Proyecto.

## Estructura de la matriz
Cuatro niveles de objetivo, cada uno con indicador, valor meta, medios de verificación y supuestos:
- **Fin** — el efecto final (ej. "Mayor nivel de desarrollo infantil temprano de los niños y niñas menores de 36 meses que viven en situación de pobreza y pobreza extrema, en [localidad, distrito, provincia, departamento]"), medido por ejemplo como "% de niños/as menores de 36 meses que logran los hitos de desarrollo infantil temprano esperados para su edad" (valor meta ilustrativo: 85%), verificado con la Encuesta de Salud y Desarrollo en la Primera Infancia.
- **Propósito** — el objetivo central (ej. "Niños y niñas entre 6 y 36 meses acceden a una adecuada prestación del servicio de cuidado diurno en [localización]"), con su indicador de cobertura/calidad (ej. "% de niños y niñas con mínimo 6 meses de permanencia que cumplen los estándares de calidad del PNCM", valor meta ilustrativo 95%) y supuestos (ej. "padres toman conciencia de la importancia del cuidado", "actores comunales comprometidos").
- **Componentes** — uno por cada componente definido en Metas Físicas y Costos (ej. Componente 1: Infraestructura del CIAI cumple con los estándares de calidad; Componente 2: Equipos; Componente 3: Mobiliario; Componente 4: Suficientes capacidades organizacionales de los recursos humanos), cada uno con su indicador de meta física (m² de infraestructura, número de equipos, número de mobiliario, número de sesiones de capacitación) y su valor, verificado en el Registro del Formato N° 09 del Banco de Inversiones.
- **Acciones** — una por componente, con el monto de ejecución (ej. "Construcción, habilitación y/o adecuación de infraestructura del CIAI — ejecución del componente por un monto de S/ ...") y su medio de verificación (recepción y conformidad de la obra/equipamiento/mobiliario/capacitación).

## Reglas
- Los montos de las Acciones deben coincidir con los del Costo de Ejecución Física de la alternativa seleccionada — no son cifras nuevas.
- Los Componentes deben ser exactamente los mismos que en Metas Físicas de los Activos (mismo número, mismo nombre) de esa alternativa.
- No inventar indicadores: si el usuario no da un valor meta, dejarlo pendiente y pedirlo en vez de aproximarlo.
