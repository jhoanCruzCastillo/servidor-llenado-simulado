# Sección 17 — SECCIÓN N°13: IMPACTO AMBIENTAL (de la alternativa seleccionada)

- id de la sección (`seccion_id` de la respuesta): `e52ec806-2e97-4ce4-a03a-127822d9f995`
- tablas de esta sección: 1 (carpeta `tablas/`)

Esta sección no tiene campos de texto para llenar (solo tablas).
