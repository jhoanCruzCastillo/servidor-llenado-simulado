# (instrucciones de esta sección)

## Objetivo
Identificar los impactos negativos que el proyecto puede generar sobre el ambiente, durante Ejecución y Funcionamiento, y plantear medidas de gestión ambiental (prevención, corrección, mitigación). **Se desarrolla para la alternativa seleccionada.**

## Impacto ambiental
Se listan los impactos negativos separados por fase — "Durante la Ejecución" y "Durante el Funcionamiento" — cada uno con su medida de mitigación y el costo de implementarla. Ejemplo real: "Generación de ruido y emisión de polvareda durante el proceso de construcción" → medida: "acciones dirigidas a controlar y evitar la generación de ruido y polvo" → costo: "se incluye dentro de las actividades previstas en el presupuesto del proyecto" (no genera un costo adicional aparte). Si no hay impactos relevantes en alguna fase, se indica "Ninguna".

## Reglas
- El costo de las medidas de mitigación debe formar parte del costo de inversión del proyecto (ya registrado en Costos del Proyecto), no un monto nuevo y separado.
- Si el usuario no identifica impactos ambientales, no inventarlos — pero sí verificar explícitamente ambas fases (Ejecución y Funcionamiento) antes de dar la sección por completa.
