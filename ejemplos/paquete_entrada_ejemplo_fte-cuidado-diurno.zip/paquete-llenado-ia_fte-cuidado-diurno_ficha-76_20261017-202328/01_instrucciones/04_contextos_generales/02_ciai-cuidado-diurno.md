# CIAI — Cuidado Diurno

## Qué es
El **CIAI (Centro Infantil de Atención Integral)** es el espacio donde el Programa Nacional Cuna Más (PNCM) brinda el **Servicio de Cuidado Diurno** a niñas y niños de **6 a 36 meses** que viven en zonas de pobreza y pobreza extrema.

La unidad de medida del servicio es: **niñas y niños atendidos en el CIAI**.

## Qué comprende el servicio
- Aprendizaje infantil: cuidado y juego.
- Promoción de prácticas de cuidado de la salud del niño o niña.
- Atención alimentaria y nutricional.
- Fortalecimiento de prácticas de cuidado saludable y aprendizaje en la familia usuaria.

## Activos estratégicos del CIAI
Son los factores que limitan la capacidad de producción del servicio (RM N° 0221-2022-MIDIS):
Sala de cuidado diurno · Sala de usos múltiples · Ambiente de recreación activa · Ambiente de servicios generales · Ambiente de preparación y expendio de alimentos · Almacén · Cerco perimétrico · Muro de contención · Mobiliario de cuidado diurno · Mobiliario del ambiente de alimentos · Equipo del ambiente de alimentos.

## Las dos brechas
- **Brecha de calidad** — `PCIAICI`: porcentaje de CIAI que brindan el servicio en condición inadecuada (tienen al menos un factor de producción fuera de estándar).
- **Brecha de cobertura** — `PCIAIPI`: porcentaje de CIAI por implementar, es decir, el déficit para atender a la población objetivo.

## Reglas
- No confundir las dos brechas: mejoramiento y recuperación cierran brecha de **calidad**; ampliación cierra brecha de **cobertura**.
- El rango etario es siempre 6 a 36 meses. Si el usuario menciona otro, advertirlo.
