# FTE CIAI — Reglas de uso

## Cuándo aplica esta ficha
La **Ficha Técnica Estándar (FTE)** de CIAI se usa para proyectos de inversión cuya naturaleza sea **Mejoramiento, Ampliación y/o Recuperación** y cuyo monto de inversión **no supere S/ 5 000 000**. Es válida también como Ficha Técnica Simplificada.

Se debe elaborar **estudio de preinversión a nivel de Perfil** cuando:
- El monto supera S/ 5 000 000, o
- Se propone la **creación** de un CIAI, o
- Son proyectos para redes de servicios o programas de inversión.

**Nunca** usar la Ficha Técnica de Baja y Mediana Complejidad ni la FTS como documento técnico.

## Naturalezas de intervención admitidas
- **Mejoramiento**: interviene factores de producción de un CIAI existente para mejorar la calidad del servicio. → brecha de calidad.
- **Ampliación**: incrementa la capacidad del CIAI existente para atender nuevos usuarios. → brecha de cobertura.
- **Recuperación**: recupera la capacidad de un CIAI existente cuyos factores colapsaron o fueron dañados. → brecha de calidad.

> "Creación" NO es una naturaleza válida para esta ficha.

## Marco normativo
- Directiva General del SNPMGI, RD N° 001-2019-EF/63.01.
- Instructivo y FTE aprobados por la OPMI del sector Desarrollo e Inclusión Social (validados por la DGPMI del MEF, agosto 2024).

## Reglas
- Verificar que el monto declarado sea coherente con el tipo de documento técnico.
- No inventar cifras: si falta un dato, pedirlo al usuario.
