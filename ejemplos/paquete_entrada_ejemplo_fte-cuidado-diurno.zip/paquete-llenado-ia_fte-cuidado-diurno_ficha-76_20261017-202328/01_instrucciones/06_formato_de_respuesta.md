# Formato de la respuesta

Entrega **un único archivo `respuesta.json`**, JSON válido (sin markdown, sin comentarios, sin texto fuera del JSON), con esta forma:

```json
{
  "secciones": [
    { "seccion_id": "<id de la sección>", "campos": [ { "id": "<identificador>", "valor_propuesto": "<texto o null>", "estado": "extraido", "confianza": 0.0, "fuente": "...", "evidencia": "..." } ] }
  ],
  "tablas": [
    { "identificador": "<identificador de la tabla>", "valor": <estructura>, "fuente": "<dónde salió la información>" }
  ]
}
```

- `secciones[]`: una entrada por cada sección de `05_secciones_a_llenar/` que tenga campos de texto (su archivo `seccion.md` lista esos campos).
- `tablas[]`: una entrada por cada archivo de `05_secciones_a_llenar/<sección>/tablas/`. Las tablas que NO se piden están en `manifiesto.json` → `tablas_omitidas`.

## Contrato de cada sección (campos)

Cada elemento de `secciones[]` sigue este contrato. Esta es la línea tal como se le pedía al modelo:

```
{"seccion_id":"<id>","campos":[{"id":"<identificador>","valor_propuesto":"<texto o null>","estado":"extraido|inferido|requiere_confirmacion|no_encontrado|conflictivo|calculado","confianza":0.0,"fuente":"...","evidencia":"..."}]}
```

## Contrato de cada tabla

Vas a llenar UNA tabla de la ficha. Respondes SIEMPRE con un único objeto JSON válido (sin markdown, sin texto fuera del JSON): {"valor": <estructura>, "fuente": "<breve descripción de dónde salió la información, ej. nombre del documento y qué parte>"}.

La forma de "valor" debe calzar EXACTAMENTE con la tabla actual que te muestran en el mensaje de usuario: mismas claves en cada fila/objeto, mismo número de filas/bloques/nodos. Nunca agregues ni quites filas, columnas o niveles — solo cambias los valores de las celdas.

## Reglas que valen siempre

- Usa **exactamente** los identificadores que aparecen en `seccion.md` y en los archivos de tabla. No inventes ids.
- Un campo se llena una sola vez, con el valor que le corresponde: nunca metas dos datos en una misma celda separados por `;` o por comas.
- Nunca toques campos calculados ni de solo lectura: el Excel los calcula solo.
- En las tablas, `valor` conserva la forma exacta que muestra su archivo (mismas claves, mismos niveles). Si el archivo de una tabla pide devolver solo las filas con datos, hazlo así.
- Los números van sin separador de miles (`2450`, no `2,450`); si necesitas decimales, usa punto (`2450.5`).
- Si un campo tiene *opciones válidas*, elige exactamente UNA, con el texto idéntico al de la opción.
