# Modo de llenado

El modo de llenado de esta ficha se decide a partir de las *Notas adicionales del cliente* (`04_proyecto_del_usuario/prompt_del_usuario.md`). Este archivo trae el bloque que rige para ESTA ficha, ya resuelto. **Prevalece sobre las reglas anteriores que digan lo contrario.**

## Para los campos de texto, número, fecha y catálogo

MODO ESTRICTO — el cliente pidió expresamente (en las "Notas adicionales del cliente") que NO inventes ni infieras datos. Este bloque prevalece sobre cualquier regla anterior que permita deducir o completar: solo vale lo que conste de forma explícita en los documentos o en las notas. Todo campo sin evidencia explícita: estado "no_encontrado" y valor_propuesto null — no uses "inferido". El "ejemplo de referencia", si lo hay, sirve solo para la FORMA — nunca como fuente de valores.

## Para las tablas

MODO ESTRICTO — el cliente pidió expresamente (en las "Notas adicionales del cliente") que NO inventes ni infieras datos. Este bloque prevalece sobre cualquier regla anterior que permita deducir o completar: solo vale lo que conste de forma explícita en los documentos o en las notas. Toda celda sin evidencia explícita queda como cadena vacía "". El "ejemplo de referencia", si lo hay, sirve solo para la FORMA — nunca como fuente de valores. En "fuente" cita únicamente documentos reales.
